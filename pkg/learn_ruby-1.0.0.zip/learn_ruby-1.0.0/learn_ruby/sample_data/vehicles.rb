$vehicles = []

$vehicles << {
    :name => 'Car',
    :wheels => 4,
    :classes => [:ground],
  }
$vehicles << {
    :name => 'Truck',
    :wheels => 4,
    :classes => [:ground],
  }
$vehicles << {
    :name => 'Boat',
    :wheels => 0,
    :classes => [:water],
  }
$vehicles << {
    :name => 'Plane',
    :wheels => 0,
    :classes => [:air],
  }
$vehicles << {
    :name => 'Helicopter',
    :wheels => 0,
    :classes => [:air],
  }
$vehicles << {
    :name => 'Bike',
    :wheels => 2,
    :classes => [:ground],
  } 
$vehicles << {
    :name => 'Sea Plane',
    :wheels => 0,
    :classes => [:air, :ground],
  }

